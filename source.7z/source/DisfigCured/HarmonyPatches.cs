﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;
using HarmonyLib;
using Verse.AI;

namespace DisfigCured
{
    [StaticConstructorOnStartup] // Special thank you to Mehdi and LWM at Ludeon Studios forum (https://wwww.ludeon.com/forum) for helping me develop this code.
    internal static class HarmonyPatches

    {
        private static Harmony harmony = new Harmony("DisfigCuredMod");

        static HarmonyPatches()
        {
            HarmonyPatches.harmony.PatchAll(Assembly.GetExecutingAssembly());
        }

        [HarmonyPatch(typeof(Hediff_AddedPart), "PostAdd")]
        private static class Patch_PostAdd
        {
            [HarmonyPriority(Priority.First)]
            private static void Postfix(Hediff_AddedPart __instance, Pawn ___pawn, BodyPartRecord ___part)
            {
                IEnumerable<BodyPartRecord> partsWithTag = ___pawn.RaceProps.body.GetPartsWithTag(BodyPartTagDefOf.Tongue);
                if (!partsWithTag.Any())
                {
                    return;
                }
                else
                {
                    BodyPartRecord tongue = ___pawn.RaceProps.body.AllParts.Find(x => x.def.defName == "Tongue");
                    HediffDef bionictonguehediff = DefDatabase<HediffDef>.GetNamed("BionicTongue");
                    if (___pawn.health.hediffSet.hediffs.Any(x => x.def.defName is "BionicJawHediff") && ___part.def.defName == "Jaw")
                    {
                        ___pawn.health.RestorePart(tongue);
                        ___pawn.health.AddHediff(bionictonguehediff, tongue);
                    }
                    return;
                }

            }

        }

    }

}